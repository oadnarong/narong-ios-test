//
//  GoogleMapAPIService.swift
//  AroundYou
//
//  Created by Narong Kanthanu on 8/2/2560 BE.
//  Copyright © 2560 nevernilmedia. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON
import CoreLocation

protocol GoogleMapAPIServiceLogic
{
    func getPlacNearbySearch(latitude: Double, longitude: Double, radius: Double, completion: @escaping (Result<[[String: AnyObject]]>) -> Void)
}

class GoogleMapAPIService: GoogleMapAPIServiceLogic
{
    func getPlacNearbySearch(latitude: Double, longitude: Double, radius: Double, completion: @escaping (Result<[[String: AnyObject]]>) -> Void) {
        let headers: HTTPHeaders = ["Accept": "application/json"]
        let parameters: Parameters = ["location": "\(String(latitude)),\(String(longitude))","radius": "\(String(radius))", "key": Lockups.GetKey().ggKey]
        Alamofire.request(Lockups.GetURL().ggPlaceUrl, method: .get, parameters: parameters, encoding: URLEncoding(destination: .methodDependent), headers: headers).validate().responseJSON { response in
            switch response.result {
            case .success:
                if let json = response.result.value {
                    
                    var placesData: Array<JSON> = []
                    let objectValue = (JSON(json))["results"]
                    print("PC: \(objectValue.count)")
                    for i in 0..<objectValue.count {
                        
                        let endLatitude = String(describing: objectValue[i]["geometry"]["location"]["lat"])
                        let endLongitude = String(describing: objectValue[i]["geometry"]["location"]["lng"])
                        
                        let distancePlaces =  self.distanceCalculator(startLatitude: latitude, startLongitude: longitude, endLatitude: Double(endLatitude)!, endLongitude: Double(endLongitude)!)
                        
                        let jsonData = JSON([
                            "place_id": String(describing: objectValue[i]["place_id"]),
                            "name": String(describing: objectValue[i]["name"]),
                            "latitude": Double(String(describing: objectValue[i]["geometry"]["location"]["lat"]))!,
                            "longitude": Double(String(describing: objectValue[i]["geometry"]["location"]["lng"]))!,
                            "photos": String(describing: (objectValue[i]["photos"])[0]["photo_reference"]),
                            "distance": String(describing: distancePlaces)
                            ])
                        
                        placesData.append(jsonData)
                    }
                    
                    DispatchQueue.main.async {
                        completion(.Success((JSON(placesData)).arrayObject as! [[String : AnyObject]]))
                    }
                }else{
                    completion(.Error("There are no new places to show"))
                }
            case .failure(let error):
                print(error)
                return completion(.Error(error.localizedDescription))
            }
        }
    }
    
    private func distanceCalculator(startLatitude: Double, startLongitude: Double, endLatitude: Double, endLongitude: Double) -> String{
        
        let coordinateStart = CLLocation(latitude: startLatitude, longitude: startLongitude)
        let coordinateEnd = CLLocation(latitude: endLatitude, longitude: endLongitude)
        let distanceInMeters = coordinateStart.distance(from: coordinateEnd)
        
        let toKilometer = (distanceInMeters / 1000)
        
        if toKilometer < 1 {
            return "\(String(format: "%.2f", distanceInMeters)) m"
        }else {
            return "\(String(format: "%.2f", toKilometer)) km"
        }
    }
    
    //    private func getPlaceDistanceNearby(startLatitude: Double, startLongitude: Double, endLatitude: Double, endLongitude: Double, completion: @escaping (distanceResult<String>) -> Void){
    //        let headers: HTTPHeaders = ["Accept": "application/json"]
    //        let parameters: Parameters = ["units": "metric", "origins": "\(String(startLatitude)),\(String(startLongitude))","destinations": "\(String(endLatitude)),\(String(endLongitude))", "key": Lockups.GetKey().ggKey]
    //        Alamofire.request(Lockups.GetURL().ggDistanceUrl, method: .get, parameters: parameters, encoding: URLEncoding(destination: .methodDependent), headers: headers).validate().responseJSON { response in
    //            switch response.result {
    //            case .success:
    //                if let json = response.result.value {
    //                    let objectValue = (JSON(json))["rows"][0]["elements"][0]["distance"]["text"]
    //                    DispatchQueue.main.async {
    //                        completion(.Success(String(describing: objectValue)))
    //                    }
    //                }
    //            case .failure(let error):
    //                print(error)
    //            }
    //        }
    //    }
}

enum Result<T> {
    case Success(T)
    case Error(String)
}

enum distanceResult<D> {
    case Success(D)
    case Error(String)
}
