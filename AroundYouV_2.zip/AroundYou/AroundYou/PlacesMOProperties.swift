//
//  PlacesMOProperties.swift
//  AroundYou
//
//  Created by Narong Kanthanu on 8/6/2560 BE.
//  Copyright © 2560 nevernilmedia. All rights reserved.
//

import Foundation
import CoreData

extension PlacesMO {
    
    @nonobjc public class func fetchRequest() -> NSFetchRequest<PlacesMO> {
        return NSFetchRequest<PlacesMO>(entityName: "Places");
    }
    
    @NSManaged var place_id: String?
    @NSManaged var distance: String?
    @NSManaged var latitude: Double
    @NSManaged var longitude: Double
    @NSManaged var name: String?
    @NSManaged var photo: String?
}
