//
//  Places.swift
//  AroundYou
//
//  Created by Narong Kanthanu on 8/6/2560 BE.
//  Copyright © 2560 nevernilmedia. All rights reserved.
//

import CoreData
import Foundation

class PlacesMO: NSManagedObject {
    
}
