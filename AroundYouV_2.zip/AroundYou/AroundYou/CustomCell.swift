//
//  CustomCell.swift
//  AroundYou
//
//  Created by Narong Kanthanu on 8/6/2560 BE.
//  Copyright © 2560 nevernilmedia. All rights reserved.
//

import UIKit

class CustomCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
