//
//  Lockups.swift
//  AroundYou
//
//  Created by Narong Kanthanu on 8/2/2560 BE.
//  Copyright © 2560 nevernilmedia. All rights reserved.
//

import UIKit

enum Lockups
{
    struct GetKey
    {
        let ggKey: String = "AIzaSyCZ1BCe4Q7YL1nCa_ovtet4Bjn52tT20T8"
    }
    struct GetURL
    {
        let ggPlaceUrl: String = "https://maps.googleapis.com/maps/api/place/nearbysearch/json"
        let ggDistanceUrl: String = "https://maps.googleapis.com/maps/api/distancematrix/json"

    }
}
