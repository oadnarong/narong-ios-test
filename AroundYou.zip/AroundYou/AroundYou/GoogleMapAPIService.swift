//
//  GoogleMapAPIService.swift
//  AroundYou
//
//  Created by Narong Kanthanu on 8/2/2560 BE.
//  Copyright © 2560 nevernilmedia. All rights reserved.
//

import UIKit
import Alamofire

protocol GoogleMapAPIServiceLogic
{
    func getPlacNearbySearch(latitude: Double, longitude: Double, radius: Double)
}

class GoogleMapAPIService: GoogleMapAPIServiceLogic
{
    func getPlacNearbySearch(latitude: Double, longitude: Double, radius: Double) {
        let headers: HTTPHeaders = ["Accept": "application/json"]
        let parameters: Parameters = ["location": "\(String(latitude)),\(String(longitude))","radius": "\(String(radius))", "key": Lockups.GetKey().ggKey]
        Alamofire.request(Lockups.GetURL().ggPlaceUrl, method: .get, parameters: parameters, encoding: URLEncoding(destination: .methodDependent), headers: headers).validate().responseJSON { response in
            print("Request: \(String(describing: response.request))")
            switch response.result {
            case .success:
                if let json = response.result.value {
                    let objectValue = (json as AnyObject)["results"] as! NSArray
                    print("TEST String data \(objectValue)")
                }
            case .failure(let error):
                print(error)
            }
        }
    }
}
